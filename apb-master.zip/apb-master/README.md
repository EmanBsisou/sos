# APB
All Point Bulletin

**Vision**
Being in a position of an emergency needing police or help does not always fit with the 111 emergency calling system. Sometimes there are dire need but no possibility of talking. It could be that the person in need is scared to talk as can be heard, or simply can not talk or no time to give details etc needed by the calling system.
We would like to create an application that sends a notification to police system that an emergency call out is needed. The application will send position of the person in need and track that person to where ever he goes until emergency arrives.


**Rest API Documentation**
https://github.com/kedarkrishnan/apb/wiki


**Tech Stack**
* Spring Boot
* Angular JS
* Android Programming
* Google API
* Blumix cloud
