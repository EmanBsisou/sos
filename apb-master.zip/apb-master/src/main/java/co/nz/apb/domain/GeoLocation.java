package co.nz.apb.domain;

public class GeoLocation {

}
